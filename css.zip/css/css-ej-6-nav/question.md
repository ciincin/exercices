Starting from the navbar you created in the HTML exercise called 'Navbar', add the CSS properties. The Search button should have a hover effect (background green and white text).

**Suggestion**:
Use the classes to apply the CSS rules instead of ids, tags, or inline style.
